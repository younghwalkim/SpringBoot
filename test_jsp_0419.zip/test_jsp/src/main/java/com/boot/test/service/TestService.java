package com.boot.test.service;

import java.util.List;

import com.boot.test.dto.Board;

public interface TestService {
	List<Board> selectList();
}
